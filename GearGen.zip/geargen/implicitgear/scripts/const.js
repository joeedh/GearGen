var _const = undefined;

define([
], function() {
  'use strict';
  
  var exports = _const = {};
  
  exports.APP_VERSION = 0.0001
  
  return exports;
});
